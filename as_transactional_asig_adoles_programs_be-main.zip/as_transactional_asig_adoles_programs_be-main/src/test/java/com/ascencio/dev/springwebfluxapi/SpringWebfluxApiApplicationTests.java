package com.ascencio.dev.springwebfluxapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebfluxApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
