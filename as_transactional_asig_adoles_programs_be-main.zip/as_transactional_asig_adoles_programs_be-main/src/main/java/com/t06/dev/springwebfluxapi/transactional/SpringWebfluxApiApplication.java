package com.t06.dev.springwebfluxapi.transactional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class SpringWebfluxApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringWebfluxApiApplication.class, args);
    }

}
