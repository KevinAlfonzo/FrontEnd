# spring-webflux-r2dbc
Proyecto de ejemplo para manejo de Pool de conexiones en PostgreSQL
